const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const  path = require("path");

const app = express();
app.use(bodyParser.json());

const PORT = 3000;

const mongoURI = 'mongodb+srv://edgarbellot:123@cluster0.t57tef8.mongodb.net/projeto?retryWrites=true&w=majority&appName=Cluster0';

mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

// User Model
const User = mongoose.model('User', {
  name: String,
  email: String,
  password: String
});


app.post('/users', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const newUser = new User({ name, email, password });
    await newUser.save();
    res.status(201).json(newUser);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});


app.get('/users', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});


app.put('/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, email, password } = req.body;
    const updatedUser = await User.findByIdAndUpdate(id, { name, email, password }, { new: true });
    res.json(updatedUser);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

app.delete('/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await User.findByIdAndDelete(id);
    res.status(204).end();
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

app.listen(PORT, () => {
  console.log('O servidor está funcionando na porta:', PORT);
});
